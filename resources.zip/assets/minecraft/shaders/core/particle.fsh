#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    vec4 color = texel * vertexColor * ColorModulator;
    // Only custom:summer_drip_land carries this two-channel marker. The red
    // channel retains the original 8x8 sprite's white/gray shading.
    if (abs(texel.g - 3.0 / 255.0) < 0.001 && abs(texel.b - 251.0 / 255.0) < 0.001) {
        color = vec4(vec3(1.0, 0.84, 0.50) * texel.r * vertexColor.r, texel.a * vertexColor.a) * ColorModulator;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
