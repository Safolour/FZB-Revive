#version 150

#extension GL_ARB_shader_draw_parameters : enable

#ifdef VULKAN

#define OFFSET_VERTEX_ID gl_VertexIndex

#else

#ifdef GL_ARB_shader_draw_parameters
#define OFFSET_VERTEX_ID (gl_VertexID - gl_BaseVertexARB)
#else
#define OFFSET_VERTEX_ID gl_VertexID
#endif

#endif

int offsetVertexId = OFFSET_VERTEX_ID;