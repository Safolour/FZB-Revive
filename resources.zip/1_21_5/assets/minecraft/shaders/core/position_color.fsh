#version 150
#define POSITION_COLOR
#moj_import <render/gui.fsh>