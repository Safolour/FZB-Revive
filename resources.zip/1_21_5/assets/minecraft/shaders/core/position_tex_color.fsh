#version 150
#define POSITION_TEX_COLOR
#moj_import <render/texture.fsh>