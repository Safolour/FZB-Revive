#version 150
#define RENDERTYPE_ITEM_ENTITY_TRANSLUCENT_CULL
#moj_import <render/item.vsh>