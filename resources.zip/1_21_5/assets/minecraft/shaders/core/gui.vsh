#version 150
#define RENDERTYPE_GUI
#moj_import <render/gui.vsh>