#version 150
#define RENDERTYPE_TEXT
#define IS_GUI
#moj_import <render/text.vsh>